const questions = [ // Declara um array chamado questions que contém objetos com pergunta, opções e resposta correta
  { question: 'Em que ano a companhia aérea Azul Linhas Aéreas foi fundada?', options: ['A) 2000', 'B) 2008', 'C) 2012', 'D) 1999', 'E) 2015'], correctAnswer: 'B) 2008', points: 10, image: "Imagens.azul/anoimg.jpg" },
  { question: 'Quem foi o fundador da Azul Linhas Aéreas?', options: ['A) Elon Musk', 'B) David Neeleman', 'C) Henrique Constantino', 'D) Richard Branson', 'E) Roberto Setúbal'], correctAnswer: 'B) David Neeleman', points: 10, image: "Imagens.azul/fundador.jpg" },
  { question: 'Qual é o principal hub da Azul?', options: ['A) Galeão (RJ)', 'B) Guarulhos (SP)', 'C) Viracopos (Campinas)', 'D) Confins (BH)', 'E) Brasília (DF)'], correctAnswer: 'C) Viracopos (Campinas)', points: 10, image: "Imagens.azul/centro.jpg" },
  { question: 'Qual desses aviões faz parte da frota da Azul?', options: ['A) Airbus A321neo', 'B) Boeing 777-300ER', 'C) Embraer E195-E2', 'D) Boeing 747-8', 'E) Airbus A380'], correctAnswer: 'C) Embraer E195-E2', points: 10, image: "Imagens.azul/aviaotop4.jpg" },
  { question: 'Qual é o programa de fidelidade da Azul?', options: ['A) Smiles', 'B) Latam Pass', 'C) TudoAzul', 'D) Azul Rewards', 'E) VoaBrasil'], correctAnswer: 'C) TudoAzul', points: 10, image: "Imagens.azul/aviaotop5.jpg" },
  { question: 'Qual destes serviços é característico da Azul durante os voos?', options: ['A) Refeição gourmet gratuita', 'B) TV ao vivo a bordo', 'C) Wi-Fi gratuito em toda a frota', 'D) Assentos totalmente reclináveis', 'E) Cabine de dois andares'], correctAnswer: 'B) TV ao vivo a bordo', points: 10, image: "Imagens.azul/aviaotop9.jpg" },
  { question: 'Em qual país a Azul possui uma companhia aérea parceira chamada Azul Cargo?', options: ['A) México', 'B) EUA', 'C) Chile', 'D) Brasil', 'E) Argentina'], correctAnswer: 'D) Brasil', points: 10, image:"Imagens.azul/aviaotop7.jpg" },
  { question: 'Qual foi o primeiro destino internacional operado pela Azul?', options: ['A) Lisboa', 'B) Montevidéu', 'C) Fort Lauderdale', 'D) Buenos Aires', 'E) Orlando'], correctAnswer: 'C) Fort Lauderdale', points: 10, image: "Imagens.azul/aviaotop8.jpg" },
  { question: 'A Azul opera muitos voos com aeronaves de qual empresa?', options: ['A) Boeing', 'B) Airbus', 'C) Comac', 'D) Bombardier', 'E) Embraer'], correctAnswer: 'E) Embraer', points: 10, image: "Imagens.azul/aviaotop6.jpg" },
  { question: 'O que tornou a Azul famosa no início?', options: ['A) Maior frota do mundo','B) Passagens de baixo custo','C) Voos supersônicos','D) Companhia 100% elétrica','E) Voos militares'], correctAnswer: 'B) Passagens de baixo custo', points: 10, image: "Imagens.azul/aviaotop10.jpg" }
];


let currentQuestion = 0; // Índice da pergunta atual (começa em 0)          
let score = 0; // Pontuação do usuário
 let timer; // Variável que guarda o intervalo do temporizador
let timeLeft = 15; // Tempo inicial por pergunta (segundos)
let userAnswers = []; // Array para guardar as respostas do usuário

const inicioContainer = document.getElementById("inicio-container"); // Referência ao container inicial
const questionContainer = document.getElementById("question-container"); // Referência ao container de perguntas
const finalPerfeito = document.getElementById("final-perfeito"); // Referência à tela final perfeita
const finalNormal = document.getElementById("final-normal"); // Referência à tela final normal
const questionTitle = document.getElementById("question"); // Elemento onde a pergunta aparece
const optionsContainer = document.getElementById("options-container"); // Elemento onde as opções aparecem
const temporizador = document.getElementById("temporizador"); // Elemento do temporizador
 const feedback = document.getElementById("feedback"); // Elemento onde aparece feedback (acertou/errou)

  document.getElementById("btn-iniciar").onclick = () => { // Quando o botão iniciar é clicado
  inicioContainer.style.display = "none"; // Esconde o container inicial
  questionContainer.style.display = "block"; // Mostra o container de perguntas
  loadQuestion(); // Chama a função que carrega a primeira pergunta
};

   function loadQuestion() { // Função para carregar e mostrar a pergunta atual
  clearInterval(timer); // Limpa qualquer temporizador antigo
  timeLeft = 15; // Reinicia o tempo
  temporizador.textContent = "Tempo: " + timeLeft + "s"; // Mostra o tempo inicial

  timer = setInterval(() => { // Cria um intervalo que diminui o tempo a cada segundo
    timeLeft--; // Decrementa o tempo
    temporizador.textContent = "Tempo: " + timeLeft + "s"; // Atualiza o texto do temporizador
    if (timeLeft <= 0) autoNext(); // Se chegar a zero chama autoNext para avançar automaticamente
  }, 1000); // 1000ms = 1s

  const q = questions[currentQuestion]; // Pega o objeto da pergunta atual
  document.body.style.backgroundImage = `url("${q.image}")`; // Troca a imagem de fundo conforme a pergunta
  questionTitle.textContent = q.question; // Coloca o texto da pergunta no elemento h2
  optionsContainer.innerHTML = ""; // Limpa as opções antigas

  q.options.forEach(option => { // Para cada opção cria um botão
    const btn = document.createElement("button"); // Cria o elemento button
    btn.textContent = option; // Define o texto do botão como a opção
    btn.className = "option-btn"; // Adiciona a classe para estilizar
    btn.onclick = () => checkAnswer(option); // Define o clique do botão para checar a resposta
    optionsContainer.appendChild(btn); // Adiciona o botão ao container de opções
  });

  feedback.textContent = ""; // Limpa mensagem de feedback
  feedback.style.border = "none"; // Remove borda do feedback
}

function checkAnswer(selected) { // Função chamada quando o usuário escolhe uma opção
  const correct = questions[currentQuestion].correctAnswer; // Recupera resposta correta da pergunta atual
  userAnswers[currentQuestion] = selected; // Salva a resposta do usuário no array

  if (selected === correct) { // Se acertou
    score += questions[currentQuestion].points; // Soma os pontos da pergunta à pontuação
    feedback.textContent = "Voo aprovado!"; // Mensagem de feedback positiva
    feedback.style.color = "#00ff00"; // Texto verde
    feedback.style.border = "5px solid #00ff00"; // Borda verde para destacar
  } else { // Se errou
    feedback.textContent = "Desvio de rota!"; // Mensagem de feedback negativa
    feedback.style.color = "#ff0000"; // Texto vermelho
    feedback.style.border = "5px solid #ff0000"; // Borda vermelha para destacar
  }

  clearInterval(timer); // Para o temporizador
  setTimeout(autoNext, 900); // Em 900ms chama autoNext para avançar (pequena pausa pra ver o feedback)
}

function autoNext() { // Função que limpa feedback e avança para próxima
  feedback.textContent = ""; // Limpa o texto do feedback
  feedback.style.border = "none"; // Remove a borda do feedback
  nextQuestion(); // Chama a função que avança para a próxima pergunta
}

function nextQuestion() { // Avança o índice da pergunta
  currentQuestion++; // Incrementa o índice
  if (currentQuestion >= questions.length) endQuiz(); // Se passou da última pergunta, termina o quiz
  else loadQuestion(); // Caso contrário carrega a próxima pergunta
}

  function endQuiz() { // Função chamada no final do quiz
  clearInterval(timer); // Garante que o temporizador está parado
  questionContainer.style.display = "none"; // Esconde o container de perguntas

  const totalMax = questions.reduce((s, q) => s + q.points, 0); // Calcula o total máximo de pontos

  const resultado = document.createElement("div"); // Cria um div para mostrar o resultado
  resultado.style.color = "white"; // Texto em branco
  resultado.style.fontSize = "22px"; // Tamanho da fonte
  resultado.style.marginBottom = "20px"; // Espaço abaixo
  resultado.textContent = `Pontuação: ${score} de ${totalMax}`; // Texto com pontuação

  const listaCorretas = document.createElement("div"); // Cria um div para listar respostas corretas
  listaCorretas.style.color = "white"; // Texto em branco
  listaCorretas.style.marginTop = "15px"; // Espaço acima
  listaCorretas.innerHTML = "<strong>Respostas corretas:</strong><br>"; // Cabeçalho da lista correta

  const listaErradas = document.createElement("div"); // Cria um div para listar respostas erradas
  listaErradas.style.color = "white"; // Texto em branco
  listaErradas.style.marginTop = "15px"; // Espaço acima
   listaErradas.innerHTML = "<strong>Respostas erradas:</strong><br>"; // Cabeçalho da lista errada

  questions.forEach((q, i) => { // Percorre todas as perguntas para montar as listas
    if (userAnswers[i] === q.correctAnswer) { // Se o usuário acertou essa pergunta
      const p = document.createElement("p"); // Cria parágrafo
      p.textContent = `${i + 1} - ${q.correctAnswer}`; // Texto: número e resposta correta
      listaCorretas.appendChild(p); // Adiciona ao bloco de corretas
    } else { // Se errou ou não respondeu
        const pErr = document.createElement("p"); // Cria parágrafo
      pErr.textContent = `${i + 1} - Você respondeu: ${userAnswers[i] || "não respondeu"} | Correto: ${q.correctAnswer}`; // Mostra o que respondeu e o correto
      listaErradas.appendChild(pErr); // Adiciona ao bloco de erradas
    }
  });

  if (score === totalMax) { // Se tirou a pontuação máxima (acertou todas)
    finalPerfeito.innerHTML = ""; // Limpa o conteúdo do container perfeito
    const h = document.createElement("h2"); // Cria elemento h2
     h.textContent = "Você acertou todas!"; // Texto do h2
    const p = document.createElement("p"); // Cria parágrafo
    p.textContent = "Parabéns! Você ganhou o prêmio!"; // Texto do parágrafo
    finalPerfeito.appendChild(h); // Adiciona h2
    finalPerfeito.appendChild(p); // Adiciona parágrafo
    finalPerfeito.appendChild(resultado); // Adiciona resultado (pontuação)
    finalPerfeito.appendChild(listaCorretas); // Adiciona lista de corretas
       finalPerfeito.style.display = "block"; // Mostra a tela de perfeito
  } else { // Caso não tenha acertado todas
    finalNormal.innerHTML = ""; // Limpa o conteúdo do container normal
    const h = document.createElement("h2"); // Cria h2
    h.textContent = "Quiz finalizado!"; // Texto do h2
    const p = document.createElement("p"); // Cria parágrafo
    p.textContent = "Você não acertou todas as perguntas, mas foi quase..."; // Mensagem encorajadora
    finalNormal.appendChild(h); // Adiciona h2
    finalNormal.appendChild(p); // Adiciona parágrafo
        finalNormal.appendChild(resultado); // Adiciona resultado (pontuação)
    finalNormal.appendChild(listaCorretas); // Adiciona lista de corretas
    finalNormal.appendChild(listaErradas); // Adiciona lista de erradas
    finalNormal.style.display = "block"; // Mostra a tela final normal
  }
}
