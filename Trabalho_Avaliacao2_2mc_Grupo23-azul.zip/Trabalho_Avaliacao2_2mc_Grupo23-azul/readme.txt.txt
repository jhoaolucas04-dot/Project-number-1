README – Quiz Corporativo Azul (Grupo 23)

Instituição: Uninassau
Disciplina: Web Coding
Professor: George Alberto
Turma: 2MC – Manhã
Data: 09/12/25

Grupo 23 – Tema: Companhia Aérea Azul

Integrantes:
Jhoão Lucas Nascimento de Lima – 01848181 – JavaScript
Matheus Kastberg dos Santos de Souza – 01816352 – CSS
Samuel Nikolas de Almeida Medeiros – 01786531 – HTML  

Descrição do Projeto

Este projeto consiste em um quiz interativo sobre a companhia aérea Azul Linhas Aéreas. O usuário responde a perguntas de múltipla escolha e, ao final, recebe a pontuação total, como um feedback detalhado indicando as respostas corretas e erradas. O objetivo é proporcionar uma experiência agradável, permitindo que os usuários do quiz ampliem seus conhecimentos sobre a Azul Linhas Aéreas enquanto se divertem.

O desenvolvimento do projeto ocorreu como parte da disciplina Web Coding da faculdade Uninassau. A base inicial do código foi fornecida pelo professor, mas diversas alterações e melhorias foram implementadas para tornar o quiz mais dinâmico e visualmente atrativo.

Funcionamento do Quiz

Ao iniciar, o quiz apresenta uma pergunta de múltipla escolha, com tempo limite de 15 segundos para resposta.

Ao selecionar uma opção, o sistema indica imediatamente se a resposta está correta ou incorreta

Correta → “Voo aprovado!”

Incorreta → “Desvio de rota!”

Ao final de todas as perguntas, o usuário visualiza:

A pontuação total

A lista de respostas corretas

A lista de respostas incorretas (quando houver)

O plano de fundo muda conforme cada pergunta, deixando a experiência mais dinâmica e visualmente envolvente.

Tecnologias Utilizadas

HTML: Estrutura da página

CSS: Estilização, transparência, blur e paleta de cores

JavaScript: Controle das perguntas, feedback, temporizador, pontuação e lista final de acertos/erros

Reaproveitamento do Código Base

A estrutura inicial em HTML e JavaScript fornecida pelo professor foi utilizada como ponto de partida, principalmente para organização das perguntas, botões e navegação entre elas.

Entretanto, a maior parte foi modificada para incluir:

Perguntas sobre a Azul

Backgrounds diferentes por questão

Feedback temático mais chamativo

Detalhamento da pontuação final

Listagem completa de respostas corretas e incorretas

Temporizador totalmente funcional

Estilização aprimorada com transparência e blur

Instruções de Uso

Para utilizar o quiz:

Abra o arquivo index.html em qualquer navegador moderno.

Clique em “Iniciar Quiz”.

Responda as perguntas dentro do tempo limite.

Veja sua pontuação e feedback completo ao final.

Navegadores testados:

Microsoft Edge

Google Chrome