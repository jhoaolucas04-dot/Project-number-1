Grupo 23 com o tema da companhia aérea Azul:
Jhoão Lucas
Matheus Kensterberg 
Samuel Nikolas

Esse projeto é um quiz interativo sobre a companhia aérea Azul Linhas Aéreas. O usuário responde perguntas e, no final, recebe a pontuação total e um feedback mostrando o que acertou ou errou. A ideia é ser divertido e educativo ao mesmo tempo.

O projeto foi feito como atividade da disciplina Web Coding da faculdade Uninassau. A base veio de um código enviado pelo professor, mas fizemos várias alterações e melhorias para deixar o quiz mais interessante e visualmente atraente.

Como funciona:

Quando o usuário inicia o quizz, aparece uma pergunta de múltipla escolha. Cada pergunta tem um tempo limite de 15 segundos. Ao escolher uma resposta, o quiz mostra imediatamente se a resposta estava correta ou incorreta certa = (voo aprovado  errada = desvio de rota). só para ficar mais interessante

 No final de todas as perguntas, aparece a pontuação total, a lista de respostas corretas e, se houver, a lista de respostas erradas. Além disso, o background muda conforme cada pergunta para deixar a experiência mais dinâmica.

Tecnologias usadas:

O projeto utiliza HTML para estruturar a página, CSS para deixar tudo bonito, com transparência, blur e cores, e JavaScript para controlar as perguntas, respostas, pontuação e temporizador.

O que foi reaproveitado do código-base:

foi utilizado o HTML e o JavaScript do código do professor como ponto de partida, principalmente a estrutura das perguntas, dos botões e a função de navegação entre perguntas. Mas a maioria foi modificado: as perguntas são sobre a Azul, os backgrounds são diferentes, foi adicionado mensagens de feedback mais chamativas, a pontuação ficou detalhada, incluímos lista de respostas corretas e erradas, e colocamos o temporizador funcionando.

Como usar:

Basta abrir o arquivo index.html em qualquer navegador moderno, clicar em Iniciar Quiz e responder as perguntas. Ao final, dá pra ver a pontuação e o feedback de cada pergunta.
para funcionar 

Estrutura do projeto:

O projeto tem a seguinte organização de pastas:

Azul-Quiz/

index.html

pasta.css.azul/ com o arquivo de estilo

pasta.js.azul/ com o script do quiz

Imagens.azul/ com todas as imagens usadas
os navedores testados foram: Edge e chrome
